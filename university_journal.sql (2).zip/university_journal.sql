-- phpMyAdmin SQL Dump
-- version 4.8.5
-- https://www.phpmyadmin.net/
--
-- Хост: localhost
-- Время создания: Ноя 27 2025 г., 23:52
-- Версия сервера: 5.7.25
-- Версия PHP: 7.1.26

SET FOREIGN_KEY_CHECKS=0;
SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- База данных: `university_journal`
--
CREATE DATABASE IF NOT EXISTS `university_journal` DEFAULT CHARACTER SET utf8 COLLATE utf8_general_ci;
USE `university_journal`;

-- --------------------------------------------------------

--
-- Структура таблицы `grades`
--

DROP TABLE IF EXISTS `grades`;
CREATE TABLE `grades` (
  `id` int(11) NOT NULL,
  `student_id` int(11) DEFAULT NULL,
  `subject_id` int(11) DEFAULT NULL,
  `grade_value` decimal(5,2) DEFAULT NULL,
  `grade_date` date DEFAULT NULL,
  `lesson_number` int(11) DEFAULT NULL,
  `grade_type` varchar(50) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- ССЫЛКИ ТАБЛИЦЫ `grades`:
--   `student_id`
--       `students` -> `student_id`
--   `subject_id`
--       `subjects` -> `subject_id`
--

--
-- Дамп данных таблицы `grades`
--

INSERT INTO `grades` (`id`, `student_id`, `subject_id`, `grade_value`, `grade_date`, `lesson_number`, `grade_type`) VALUES(1, 1, 1, '4.50', '2024-01-15', NULL, 'текущая');
INSERT INTO `grades` (`id`, `student_id`, `subject_id`, `grade_value`, `grade_date`, `lesson_number`, `grade_type`) VALUES(2, 1, 1, '5.00', '2024-01-22', NULL, 'текущая');
INSERT INTO `grades` (`id`, `student_id`, `subject_id`, `grade_value`, `grade_date`, `lesson_number`, `grade_type`) VALUES(3, 1, 5, '4.00', '2024-01-16', NULL, 'текущая');
INSERT INTO `grades` (`id`, `student_id`, `subject_id`, `grade_value`, `grade_date`, `lesson_number`, `grade_type`) VALUES(4, 2, 1, '3.50', '2024-01-15', NULL, 'текущая');
INSERT INTO `grades` (`id`, `student_id`, `subject_id`, `grade_value`, `grade_date`, `lesson_number`, `grade_type`) VALUES(5, 2, 5, '5.00', '2024-01-16', NULL, 'текущая');
INSERT INTO `grades` (`id`, `student_id`, `subject_id`, `grade_value`, `grade_date`, `lesson_number`, `grade_type`) VALUES(6, 3, 1, '4.00', '2024-01-15', NULL, 'текущая');
INSERT INTO `grades` (`id`, `student_id`, `subject_id`, `grade_value`, `grade_date`, `lesson_number`, `grade_type`) VALUES(7, 3, 5, '4.50', '2024-01-17', NULL, 'текущая');
INSERT INTO `grades` (`id`, `student_id`, `subject_id`, `grade_value`, `grade_date`, `lesson_number`, `grade_type`) VALUES(8, 4, 1, '5.00', '2024-01-16', NULL, 'текущая');
INSERT INTO `grades` (`id`, `student_id`, `subject_id`, `grade_value`, `grade_date`, `lesson_number`, `grade_type`) VALUES(9, 4, 5, '4.00', '2024-01-18', NULL, 'текущая');
INSERT INTO `grades` (`id`, `student_id`, `subject_id`, `grade_value`, `grade_date`, `lesson_number`, `grade_type`) VALUES(10, 5, 1, '3.00', '2024-01-15', NULL, 'текущая');
INSERT INTO `grades` (`id`, `student_id`, `subject_id`, `grade_value`, `grade_date`, `lesson_number`, `grade_type`) VALUES(11, 6, 2, '4.50', '2024-01-15', NULL, 'текущая');
INSERT INTO `grades` (`id`, `student_id`, `subject_id`, `grade_value`, `grade_date`, `lesson_number`, `grade_type`) VALUES(12, 6, 3, '5.00', '2024-01-22', NULL, 'текущая');
INSERT INTO `grades` (`id`, `student_id`, `subject_id`, `grade_value`, `grade_date`, `lesson_number`, `grade_type`) VALUES(13, 7, 2, '4.00', '2024-01-16', NULL, 'текущая');
INSERT INTO `grades` (`id`, `student_id`, `subject_id`, `grade_value`, `grade_date`, `lesson_number`, `grade_type`) VALUES(14, 7, 6, '4.50', '2024-01-17', NULL, 'текущая');
INSERT INTO `grades` (`id`, `student_id`, `subject_id`, `grade_value`, `grade_date`, `lesson_number`, `grade_type`) VALUES(15, 8, 3, '5.00', '2024-01-16', NULL, 'текущая');
INSERT INTO `grades` (`id`, `student_id`, `subject_id`, `grade_value`, `grade_date`, `lesson_number`, `grade_type`) VALUES(16, 8, 4, '4.00', '2024-01-18', NULL, 'текущая');
INSERT INTO `grades` (`id`, `student_id`, `subject_id`, `grade_value`, `grade_date`, `lesson_number`, `grade_type`) VALUES(17, 9, 2, '3.50', '2024-01-15', NULL, 'текущая');
INSERT INTO `grades` (`id`, `student_id`, `subject_id`, `grade_value`, `grade_date`, `lesson_number`, `grade_type`) VALUES(18, 10, 6, '5.00', '2024-01-16', NULL, 'текущая');
INSERT INTO `grades` (`id`, `student_id`, `subject_id`, `grade_value`, `grade_date`, `lesson_number`, `grade_type`) VALUES(19, 1, 5, NULL, '2025-11-18', 1, NULL);
INSERT INTO `grades` (`id`, `student_id`, `subject_id`, `grade_value`, `grade_date`, `lesson_number`, `grade_type`) VALUES(20, 2, 5, NULL, '2025-11-18', 1, NULL);
INSERT INTO `grades` (`id`, `student_id`, `subject_id`, `grade_value`, `grade_date`, `lesson_number`, `grade_type`) VALUES(21, 3, 5, NULL, '2025-11-18', 1, NULL);
INSERT INTO `grades` (`id`, `student_id`, `subject_id`, `grade_value`, `grade_date`, `lesson_number`, `grade_type`) VALUES(22, 4, 5, NULL, '2025-11-18', 1, NULL);
INSERT INTO `grades` (`id`, `student_id`, `subject_id`, `grade_value`, `grade_date`, `lesson_number`, `grade_type`) VALUES(23, 5, 5, NULL, '2025-11-18', 1, NULL);
INSERT INTO `grades` (`id`, `student_id`, `subject_id`, `grade_value`, `grade_date`, `lesson_number`, `grade_type`) VALUES(24, 1, 5, NULL, '2025-11-18', 2, NULL);
INSERT INTO `grades` (`id`, `student_id`, `subject_id`, `grade_value`, `grade_date`, `lesson_number`, `grade_type`) VALUES(25, 2, 5, NULL, '2025-11-18', 2, NULL);
INSERT INTO `grades` (`id`, `student_id`, `subject_id`, `grade_value`, `grade_date`, `lesson_number`, `grade_type`) VALUES(26, 3, 5, NULL, '2025-11-18', 2, NULL);
INSERT INTO `grades` (`id`, `student_id`, `subject_id`, `grade_value`, `grade_date`, `lesson_number`, `grade_type`) VALUES(27, 4, 5, NULL, '2025-11-18', 2, NULL);
INSERT INTO `grades` (`id`, `student_id`, `subject_id`, `grade_value`, `grade_date`, `lesson_number`, `grade_type`) VALUES(28, 5, 5, NULL, '2025-11-18', 2, NULL);
INSERT INTO `grades` (`id`, `student_id`, `subject_id`, `grade_value`, `grade_date`, `lesson_number`, `grade_type`) VALUES(29, 1, 5, NULL, '2025-11-17', 2, NULL);
INSERT INTO `grades` (`id`, `student_id`, `subject_id`, `grade_value`, `grade_date`, `lesson_number`, `grade_type`) VALUES(30, 2, 5, '3.00', '2025-11-17', 2, NULL);
INSERT INTO `grades` (`id`, `student_id`, `subject_id`, `grade_value`, `grade_date`, `lesson_number`, `grade_type`) VALUES(31, 3, 5, NULL, '2025-11-17', 2, NULL);
INSERT INTO `grades` (`id`, `student_id`, `subject_id`, `grade_value`, `grade_date`, `lesson_number`, `grade_type`) VALUES(32, 4, 5, NULL, '2025-11-17', 2, NULL);
INSERT INTO `grades` (`id`, `student_id`, `subject_id`, `grade_value`, `grade_date`, `lesson_number`, `grade_type`) VALUES(33, 5, 5, NULL, '2025-11-17', 2, NULL);
INSERT INTO `grades` (`id`, `student_id`, `subject_id`, `grade_value`, `grade_date`, `lesson_number`, `grade_type`) VALUES(34, 1, 5, NULL, '2025-11-17', 1, NULL);
INSERT INTO `grades` (`id`, `student_id`, `subject_id`, `grade_value`, `grade_date`, `lesson_number`, `grade_type`) VALUES(35, 2, 5, NULL, '2025-11-17', 1, NULL);
INSERT INTO `grades` (`id`, `student_id`, `subject_id`, `grade_value`, `grade_date`, `lesson_number`, `grade_type`) VALUES(36, 3, 5, NULL, '2025-11-17', 1, NULL);
INSERT INTO `grades` (`id`, `student_id`, `subject_id`, `grade_value`, `grade_date`, `lesson_number`, `grade_type`) VALUES(37, 4, 5, '4.00', '2025-11-17', 1, NULL);
INSERT INTO `grades` (`id`, `student_id`, `subject_id`, `grade_value`, `grade_date`, `lesson_number`, `grade_type`) VALUES(38, 5, 5, NULL, '2025-11-17', 1, NULL);
INSERT INTO `grades` (`id`, `student_id`, `subject_id`, `grade_value`, `grade_date`, `lesson_number`, `grade_type`) VALUES(39, 1, 5, NULL, '2025-11-13', NULL, NULL);
INSERT INTO `grades` (`id`, `student_id`, `subject_id`, `grade_value`, `grade_date`, `lesson_number`, `grade_type`) VALUES(40, 2, 5, NULL, '2025-11-13', NULL, NULL);
INSERT INTO `grades` (`id`, `student_id`, `subject_id`, `grade_value`, `grade_date`, `lesson_number`, `grade_type`) VALUES(41, 3, 5, '5.00', '2025-11-13', NULL, NULL);
INSERT INTO `grades` (`id`, `student_id`, `subject_id`, `grade_value`, `grade_date`, `lesson_number`, `grade_type`) VALUES(42, 4, 5, NULL, '2025-11-13', NULL, NULL);
INSERT INTO `grades` (`id`, `student_id`, `subject_id`, `grade_value`, `grade_date`, `lesson_number`, `grade_type`) VALUES(43, 5, 5, '2.00', '2025-11-13', NULL, NULL);
INSERT INTO `grades` (`id`, `student_id`, `subject_id`, `grade_value`, `grade_date`, `lesson_number`, `grade_type`) VALUES(44, 1, 5, NULL, '2025-11-14', NULL, NULL);
INSERT INTO `grades` (`id`, `student_id`, `subject_id`, `grade_value`, `grade_date`, `lesson_number`, `grade_type`) VALUES(45, 2, 5, NULL, '2025-11-14', NULL, NULL);
INSERT INTO `grades` (`id`, `student_id`, `subject_id`, `grade_value`, `grade_date`, `lesson_number`, `grade_type`) VALUES(46, 3, 5, NULL, '2025-11-14', NULL, NULL);
INSERT INTO `grades` (`id`, `student_id`, `subject_id`, `grade_value`, `grade_date`, `lesson_number`, `grade_type`) VALUES(47, 4, 5, '5.00', '2025-11-14', NULL, NULL);
INSERT INTO `grades` (`id`, `student_id`, `subject_id`, `grade_value`, `grade_date`, `lesson_number`, `grade_type`) VALUES(48, 5, 5, NULL, '2025-11-14', NULL, NULL);
INSERT INTO `grades` (`id`, `student_id`, `subject_id`, `grade_value`, `grade_date`, `lesson_number`, `grade_type`) VALUES(49, 1, 5, NULL, '2025-11-14', 2, NULL);
INSERT INTO `grades` (`id`, `student_id`, `subject_id`, `grade_value`, `grade_date`, `lesson_number`, `grade_type`) VALUES(50, 2, 5, NULL, '2025-11-14', 2, NULL);
INSERT INTO `grades` (`id`, `student_id`, `subject_id`, `grade_value`, `grade_date`, `lesson_number`, `grade_type`) VALUES(51, 3, 5, NULL, '2025-11-14', 2, NULL);
INSERT INTO `grades` (`id`, `student_id`, `subject_id`, `grade_value`, `grade_date`, `lesson_number`, `grade_type`) VALUES(52, 4, 5, NULL, '2025-11-14', 2, NULL);
INSERT INTO `grades` (`id`, `student_id`, `subject_id`, `grade_value`, `grade_date`, `lesson_number`, `grade_type`) VALUES(53, 5, 5, '3.00', '2025-11-14', 2, NULL);
INSERT INTO `grades` (`id`, `student_id`, `subject_id`, `grade_value`, `grade_date`, `lesson_number`, `grade_type`) VALUES(54, 5, 5, '3.00', '2025-01-17', NULL, NULL);
INSERT INTO `grades` (`id`, `student_id`, `subject_id`, `grade_value`, `grade_date`, `lesson_number`, `grade_type`) VALUES(65, 38, 1, '4.50', '2025-11-25', NULL, 'текущая');
INSERT INTO `grades` (`id`, `student_id`, `subject_id`, `grade_value`, `grade_date`, `lesson_number`, `grade_type`) VALUES(66, 38, 5, '5.00', '2025-11-26', NULL, 'текущая');
INSERT INTO `grades` (`id`, `student_id`, `subject_id`, `grade_value`, `grade_date`, `lesson_number`, `grade_type`) VALUES(67, 39, 1, '4.00', '2025-11-25', NULL, 'текущая');
INSERT INTO `grades` (`id`, `student_id`, `subject_id`, `grade_value`, `grade_date`, `lesson_number`, `grade_type`) VALUES(68, 39, 5, '4.50', '2025-11-26', NULL, 'текущая');
INSERT INTO `grades` (`id`, `student_id`, `subject_id`, `grade_value`, `grade_date`, `lesson_number`, `grade_type`) VALUES(69, 40, 1, '5.00', '2025-11-25', NULL, 'текущая');
INSERT INTO `grades` (`id`, `student_id`, `subject_id`, `grade_value`, `grade_date`, `lesson_number`, `grade_type`) VALUES(70, 40, 5, '4.00', '2025-11-26', NULL, 'текущая');
INSERT INTO `grades` (`id`, `student_id`, `subject_id`, `grade_value`, `grade_date`, `lesson_number`, `grade_type`) VALUES(71, 41, 1, '3.50', '2025-11-25', NULL, 'текущая');
INSERT INTO `grades` (`id`, `student_id`, `subject_id`, `grade_value`, `grade_date`, `lesson_number`, `grade_type`) VALUES(72, 41, 5, '5.00', '2025-11-26', NULL, 'текущая');
INSERT INTO `grades` (`id`, `student_id`, `subject_id`, `grade_value`, `grade_date`, `lesson_number`, `grade_type`) VALUES(73, 42, 1, '4.00', '2025-11-25', NULL, 'текущая');
INSERT INTO `grades` (`id`, `student_id`, `subject_id`, `grade_value`, `grade_date`, `lesson_number`, `grade_type`) VALUES(74, 42, 5, '4.50', '2025-11-26', NULL, 'текущая');
INSERT INTO `grades` (`id`, `student_id`, `subject_id`, `grade_value`, `grade_date`, `lesson_number`, `grade_type`) VALUES(80, 43, 2, '4.50', '2025-11-25', NULL, 'текущая');
INSERT INTO `grades` (`id`, `student_id`, `subject_id`, `grade_value`, `grade_date`, `lesson_number`, `grade_type`) VALUES(81, 43, 3, '5.00', '2025-11-26', NULL, 'текущая');
INSERT INTO `grades` (`id`, `student_id`, `subject_id`, `grade_value`, `grade_date`, `lesson_number`, `grade_type`) VALUES(82, 44, 2, '4.00', '2025-11-25', NULL, 'текущая');
INSERT INTO `grades` (`id`, `student_id`, `subject_id`, `grade_value`, `grade_date`, `lesson_number`, `grade_type`) VALUES(83, 44, 3, '4.50', '2025-11-26', NULL, 'текущая');
INSERT INTO `grades` (`id`, `student_id`, `subject_id`, `grade_value`, `grade_date`, `lesson_number`, `grade_type`) VALUES(84, 45, 2, '5.00', '2025-11-25', NULL, 'текущая');
INSERT INTO `grades` (`id`, `student_id`, `subject_id`, `grade_value`, `grade_date`, `lesson_number`, `grade_type`) VALUES(85, 45, 3, '4.00', '2025-11-26', NULL, 'текущая');
INSERT INTO `grades` (`id`, `student_id`, `subject_id`, `grade_value`, `grade_date`, `lesson_number`, `grade_type`) VALUES(86, 46, 2, '3.50', '2025-11-25', NULL, 'текущая');
INSERT INTO `grades` (`id`, `student_id`, `subject_id`, `grade_value`, `grade_date`, `lesson_number`, `grade_type`) VALUES(87, 46, 3, '5.00', '2025-11-26', NULL, 'текущая');
INSERT INTO `grades` (`id`, `student_id`, `subject_id`, `grade_value`, `grade_date`, `lesson_number`, `grade_type`) VALUES(88, 47, 2, '4.00', '2025-11-25', NULL, 'текущая');
INSERT INTO `grades` (`id`, `student_id`, `subject_id`, `grade_value`, `grade_date`, `lesson_number`, `grade_type`) VALUES(89, 47, 3, '4.50', '2025-11-26', NULL, 'текущая');
INSERT INTO `grades` (`id`, `student_id`, `subject_id`, `grade_value`, `grade_date`, `lesson_number`, `grade_type`) VALUES(95, 48, 4, '5.00', '2025-11-25', NULL, 'текущая');
INSERT INTO `grades` (`id`, `student_id`, `subject_id`, `grade_value`, `grade_date`, `lesson_number`, `grade_type`) VALUES(96, 48, 6, '4.50', '2025-11-26', NULL, 'текущая');
INSERT INTO `grades` (`id`, `student_id`, `subject_id`, `grade_value`, `grade_date`, `lesson_number`, `grade_type`) VALUES(97, 49, 4, '4.00', '2025-11-25', NULL, 'текущая');
INSERT INTO `grades` (`id`, `student_id`, `subject_id`, `grade_value`, `grade_date`, `lesson_number`, `grade_type`) VALUES(98, 49, 6, '5.00', '2025-11-26', NULL, 'текущая');
INSERT INTO `grades` (`id`, `student_id`, `subject_id`, `grade_value`, `grade_date`, `lesson_number`, `grade_type`) VALUES(99, 50, 4, '4.50', '2025-11-25', NULL, 'текущая');
INSERT INTO `grades` (`id`, `student_id`, `subject_id`, `grade_value`, `grade_date`, `lesson_number`, `grade_type`) VALUES(100, 50, 6, '4.00', '2025-11-26', NULL, 'текущая');
INSERT INTO `grades` (`id`, `student_id`, `subject_id`, `grade_value`, `grade_date`, `lesson_number`, `grade_type`) VALUES(101, 51, 4, '5.00', '2025-11-25', NULL, 'текущая');
INSERT INTO `grades` (`id`, `student_id`, `subject_id`, `grade_value`, `grade_date`, `lesson_number`, `grade_type`) VALUES(102, 51, 6, '4.50', '2025-11-26', NULL, 'текущая');
INSERT INTO `grades` (`id`, `student_id`, `subject_id`, `grade_value`, `grade_date`, `lesson_number`, `grade_type`) VALUES(103, 52, 4, '3.50', '2025-11-25', NULL, 'текущая');
INSERT INTO `grades` (`id`, `student_id`, `subject_id`, `grade_value`, `grade_date`, `lesson_number`, `grade_type`) VALUES(104, 52, 6, '5.00', '2025-11-26', NULL, 'текущая');

--
-- Триггеры `grades`
--
DROP TRIGGER IF EXISTS `prevent_duplicate_lessons`;
DELIMITER $$
CREATE TRIGGER `prevent_duplicate_lessons` BEFORE INSERT ON `grades` FOR EACH ROW BEGIN
    DECLARE duplicate_count INT DEFAULT 0;
    
    -- Проверяем дубликаты с учетом NULL
    SELECT COUNT(*) INTO duplicate_count
    FROM Grades
    WHERE student_id = NEW.student_id
      AND subject_id = NEW.subject_id
      AND grade_date = NEW.grade_date
      AND (
          -- Случай 1: Оба NULL
          (lesson_number IS NULL AND NEW.lesson_number IS NULL) OR
          -- Случай 2: Оба не NULL и равны
          (lesson_number IS NOT NULL AND NEW.lesson_number IS NOT NULL AND lesson_number = NEW.lesson_number)
      );
    
    IF duplicate_count > 0 THEN
        SIGNAL SQLSTATE '45000' SET MESSAGE_TEXT = 'Duplicate lesson entry';
    END IF;
END
$$
DELIMITER ;

-- --------------------------------------------------------

--
-- Структура таблицы `specialties`
--

DROP TABLE IF EXISTS `specialties`;
CREATE TABLE `specialties` (
  `specialty_id` int(11) NOT NULL,
  `specialty_name` varchar(100) NOT NULL,
  `group_name` varchar(50) NOT NULL,
  `course` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- ССЫЛКИ ТАБЛИЦЫ `specialties`:
--

--
-- Дамп данных таблицы `specialties`
--

INSERT INTO `specialties` (`specialty_id`, `specialty_name`, `group_name`, `course`) VALUES(1, 'Информационные системы и программирование', 'П-10', 1);
INSERT INTO `specialties` (`specialty_id`, `specialty_name`, `group_name`, `course`) VALUES(2, 'Информационные системы и программирование', 'П-20', 2);
INSERT INTO `specialties` (`specialty_id`, `specialty_name`, `group_name`, `course`) VALUES(3, 'Информационные системы и программирование', 'П-31', 3);

-- --------------------------------------------------------

--
-- Структура таблицы `students`
--

DROP TABLE IF EXISTS `students`;
CREATE TABLE `students` (
  `student_id` int(11) NOT NULL,
  `last_name` varchar(100) NOT NULL,
  `first_name` varchar(100) NOT NULL,
  `middle_name` varchar(100) DEFAULT NULL,
  `specialty_id` int(11) DEFAULT NULL,
  `group_name` varchar(50) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- ССЫЛКИ ТАБЛИЦЫ `students`:
--   `specialty_id`
--       `specialties` -> `specialty_id`
--   `group_name`
--       `specialties` -> `group_name`
--

--
-- Дамп данных таблицы `students`
--

INSERT INTO `students` (`student_id`, `last_name`, `first_name`, `middle_name`, `specialty_id`, `group_name`) VALUES(1, 'Смирнов', 'Алексей', 'Петрович', 1, 'П-10');
INSERT INTO `students` (`student_id`, `last_name`, `first_name`, `middle_name`, `specialty_id`, `group_name`) VALUES(2, 'Кузнецова', 'Елена', 'Сергеевна', 1, 'П-10');
INSERT INTO `students` (`student_id`, `last_name`, `first_name`, `middle_name`, `specialty_id`, `group_name`) VALUES(3, 'Попов', 'Дмитрий', 'Игоревич', 1, 'П-10');
INSERT INTO `students` (`student_id`, `last_name`, `first_name`, `middle_name`, `specialty_id`, `group_name`) VALUES(4, 'Орлов', 'Иван', 'Александрович', 1, 'П-10');
INSERT INTO `students` (`student_id`, `last_name`, `first_name`, `middle_name`, `specialty_id`, `group_name`) VALUES(5, 'Лебедева', 'Мария', 'Дмитриевна', 1, 'П-10');
INSERT INTO `students` (`student_id`, `last_name`, `first_name`, `middle_name`, `specialty_id`, `group_name`) VALUES(6, 'Васильев', 'Максим', 'Александрович', 2, 'П-20');
INSERT INTO `students` (`student_id`, `last_name`, `first_name`, `middle_name`, `specialty_id`, `group_name`) VALUES(7, 'Новикова', 'Анна', 'Владимировна', 2, 'П-20');
INSERT INTO `students` (`student_id`, `last_name`, `first_name`, `middle_name`, `specialty_id`, `group_name`) VALUES(8, 'Морозов', 'Иван', 'Дмитриевич', 2, 'П-20');
INSERT INTO `students` (`student_id`, `last_name`, `first_name`, `middle_name`, `specialty_id`, `group_name`) VALUES(9, 'Волкова', 'Светлана', 'Алексеевна', 2, 'П-20');
INSERT INTO `students` (`student_id`, `last_name`, `first_name`, `middle_name`, `specialty_id`, `group_name`) VALUES(10, 'Алексеев', 'Сергей', 'Павлович', 2, 'П-20');
INSERT INTO `students` (`student_id`, `last_name`, `first_name`, `middle_name`, `specialty_id`, `group_name`) VALUES(16, 'Комаров', 'Артем', 'Витальевич', NULL, 'П-10');
INSERT INTO `students` (`student_id`, `last_name`, `first_name`, `middle_name`, `specialty_id`, `group_name`) VALUES(17, 'Захарова', 'София', 'Романовна', NULL, 'П-10');
INSERT INTO `students` (`student_id`, `last_name`, `first_name`, `middle_name`, `specialty_id`, `group_name`) VALUES(18, 'Белов', 'Кирилл', 'Андреевич', NULL, 'П-10');
INSERT INTO `students` (`student_id`, `last_name`, `first_name`, `middle_name`, `specialty_id`, `group_name`) VALUES(19, 'Григорьева', 'Алина', 'Сергеевна', NULL, 'П-10');
INSERT INTO `students` (`student_id`, `last_name`, `first_name`, `middle_name`, `specialty_id`, `group_name`) VALUES(20, 'Титов', 'Максим', 'Владимирович', NULL, 'П-10');
INSERT INTO `students` (`student_id`, `last_name`, `first_name`, `middle_name`, `specialty_id`, `group_name`) VALUES(21, 'Сорокина', 'Виктория', 'Игоревна', NULL, 'П-10');
INSERT INTO `students` (`student_id`, `last_name`, `first_name`, `middle_name`, `specialty_id`, `group_name`) VALUES(22, 'Филиппов', 'Даниил', 'Олегович', NULL, 'П-10');
INSERT INTO `students` (`student_id`, `last_name`, `first_name`, `middle_name`, `specialty_id`, `group_name`) VALUES(23, 'Жукова', 'Полина', 'Алексеевна', NULL, 'П-10');
INSERT INTO `students` (`student_id`, `last_name`, `first_name`, `middle_name`, `specialty_id`, `group_name`) VALUES(24, 'Данилов', 'Михаил', 'Юрьевич', NULL, 'П-20');
INSERT INTO `students` (`student_id`, `last_name`, `first_name`, `middle_name`, `specialty_id`, `group_name`) VALUES(25, 'Ефимова', 'Ангелина', 'Денисовна', NULL, 'П-20');
INSERT INTO `students` (`student_id`, `last_name`, `first_name`, `middle_name`, `specialty_id`, `group_name`) VALUES(26, 'Щербаков', 'Станислав', 'Викторович', NULL, 'П-20');
INSERT INTO `students` (`student_id`, `last_name`, `first_name`, `middle_name`, `specialty_id`, `group_name`) VALUES(27, 'Блинова', 'Ксения', 'Павловна', NULL, 'П-20');
INSERT INTO `students` (`student_id`, `last_name`, `first_name`, `middle_name`, `specialty_id`, `group_name`) VALUES(28, 'Крылов', 'Георгий', 'Артемович', NULL, 'П-20');
INSERT INTO `students` (`student_id`, `last_name`, `first_name`, `middle_name`, `specialty_id`, `group_name`) VALUES(29, 'Ларина', 'Дарья', 'Владимировна', NULL, 'П-20');
INSERT INTO `students` (`student_id`, `last_name`, `first_name`, `middle_name`, `specialty_id`, `group_name`) VALUES(30, 'Савельев', 'Евгений', 'Ильич', NULL, 'П-20');
INSERT INTO `students` (`student_id`, `last_name`, `first_name`, `middle_name`, `specialty_id`, `group_name`) VALUES(31, 'Мельникова', 'Валерия', 'Анатольевна', NULL, 'П-20');
INSERT INTO `students` (`student_id`, `last_name`, `first_name`, `middle_name`, `specialty_id`, `group_name`) VALUES(38, 'Комаров', 'Андрей', 'Владимирович', 1, 'П-10');
INSERT INTO `students` (`student_id`, `last_name`, `first_name`, `middle_name`, `specialty_id`, `group_name`) VALUES(39, 'Белова', 'Екатерина', 'Сергеевна', 1, 'П-10');
INSERT INTO `students` (`student_id`, `last_name`, `first_name`, `middle_name`, `specialty_id`, `group_name`) VALUES(40, 'Щербаков', 'Михаил', 'Александрович', 1, 'П-10');
INSERT INTO `students` (`student_id`, `last_name`, `first_name`, `middle_name`, `specialty_id`, `group_name`) VALUES(41, 'Воробьева', 'Алина', 'Дмитриевна', 1, 'П-10');
INSERT INTO `students` (`student_id`, `last_name`, `first_name`, `middle_name`, `specialty_id`, `group_name`) VALUES(42, 'Крылов', 'Арсений', 'Олегович', 1, 'П-10');
INSERT INTO `students` (`student_id`, `last_name`, `first_name`, `middle_name`, `specialty_id`, `group_name`) VALUES(43, 'Горбачев', 'Станислав', 'Викторович', 2, 'П-20');
INSERT INTO `students` (`student_id`, `last_name`, `first_name`, `middle_name`, `specialty_id`, `group_name`) VALUES(44, 'Зайцева', 'Виктория', 'Андреевна', 2, 'П-20');
INSERT INTO `students` (`student_id`, `last_name`, `first_name`, `middle_name`, `specialty_id`, `group_name`) VALUES(45, 'Мельников', 'Георгий', 'Павлович', 2, 'П-20');
INSERT INTO `students` (`student_id`, `last_name`, `first_name`, `middle_name`, `specialty_id`, `group_name`) VALUES(46, 'Сафонова', 'Юлия', 'Игоревна', 2, 'П-20');
INSERT INTO `students` (`student_id`, `last_name`, `first_name`, `middle_name`, `specialty_id`, `group_name`) VALUES(47, 'Егоров', 'Тимур', 'Романович', 2, 'П-20');
INSERT INTO `students` (`student_id`, `last_name`, `first_name`, `middle_name`, `specialty_id`, `group_name`) VALUES(48, 'Григорьев', 'Артем', 'Викторович', 3, 'П-31');
INSERT INTO `students` (`student_id`, `last_name`, `first_name`, `middle_name`, `specialty_id`, `group_name`) VALUES(49, 'Семенова', 'Дарья', 'Олеговна', 3, 'П-31');
INSERT INTO `students` (`student_id`, `last_name`, `first_name`, `middle_name`, `specialty_id`, `group_name`) VALUES(50, 'Тихонов', 'Роман', 'Сергеевич', 3, 'П-31');
INSERT INTO `students` (`student_id`, `last_name`, `first_name`, `middle_name`, `specialty_id`, `group_name`) VALUES(51, 'Фролова', 'Кристина', 'Андреевна', 3, 'П-31');
INSERT INTO `students` (`student_id`, `last_name`, `first_name`, `middle_name`, `specialty_id`, `group_name`) VALUES(52, 'Данилов', 'Павел', 'Игоревич', 3, 'П-31');
INSERT INTO `students` (`student_id`, `last_name`, `first_name`, `middle_name`, `specialty_id`, `group_name`) VALUES(53, 'Максимов', 'Владислав', 'Артемович', 3, 'П-31');
INSERT INTO `students` (`student_id`, `last_name`, `first_name`, `middle_name`, `specialty_id`, `group_name`) VALUES(54, 'Орлова', 'Ангелина', 'Витальевна', 3, 'П-31');
INSERT INTO `students` (`student_id`, `last_name`, `first_name`, `middle_name`, `specialty_id`, `group_name`) VALUES(55, 'Суханов', 'Илья', 'Денисович', 3, 'П-31');
INSERT INTO `students` (`student_id`, `last_name`, `first_name`, `middle_name`, `specialty_id`, `group_name`) VALUES(56, 'Ткаченко', 'Валерия', 'Анатольевна', 3, 'П-31');
INSERT INTO `students` (`student_id`, `last_name`, `first_name`, `middle_name`, `specialty_id`, `group_name`) VALUES(57, 'Жуков', 'Константин', 'Степанович', 3, 'П-31');

-- --------------------------------------------------------

--
-- Структура таблицы `subjects`
--

DROP TABLE IF EXISTS `subjects`;
CREATE TABLE `subjects` (
  `subject_id` int(11) NOT NULL,
  `subject_name` varchar(150) NOT NULL,
  `teacher_id` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- ССЫЛКИ ТАБЛИЦЫ `subjects`:
--   `teacher_id`
--       `teachers` -> `teacher_id`
--

--
-- Дамп данных таблицы `subjects`
--

INSERT INTO `subjects` (`subject_id`, `subject_name`, `teacher_id`) VALUES(1, 'Основы программирования', 1);
INSERT INTO `subjects` (`subject_id`, `subject_name`, `teacher_id`) VALUES(2, 'Базы данных', 2);
INSERT INTO `subjects` (`subject_id`, `subject_name`, `teacher_id`) VALUES(3, 'Веб-технологии', 3);
INSERT INTO `subjects` (`subject_id`, `subject_name`, `teacher_id`) VALUES(4, 'Операционные системы', 4);
INSERT INTO `subjects` (`subject_id`, `subject_name`, `teacher_id`) VALUES(5, 'Математика', 1);
INSERT INTO `subjects` (`subject_id`, `subject_name`, `teacher_id`) VALUES(6, 'Алгоритмы и структуры данных', 2);

-- --------------------------------------------------------

--
-- Структура таблицы `teachers`
--

DROP TABLE IF EXISTS `teachers`;
CREATE TABLE `teachers` (
  `teacher_id` int(11) NOT NULL,
  `last_name` varchar(100) NOT NULL,
  `first_name` varchar(100) NOT NULL,
  `middle_name` varchar(100) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- ССЫЛКИ ТАБЛИЦЫ `teachers`:
--

--
-- Дамп данных таблицы `teachers`
--

INSERT INTO `teachers` (`teacher_id`, `last_name`, `first_name`, `middle_name`) VALUES(1, 'Иванов', 'Петр', 'Сергеевич');
INSERT INTO `teachers` (`teacher_id`, `last_name`, `first_name`, `middle_name`) VALUES(2, 'Петрова', 'Мария', 'Ивановна');
INSERT INTO `teachers` (`teacher_id`, `last_name`, `first_name`, `middle_name`) VALUES(3, 'Сидоров', 'Алексей', 'Владимирович');
INSERT INTO `teachers` (`teacher_id`, `last_name`, `first_name`, `middle_name`) VALUES(4, 'Козлова', 'Ольга', 'Дмитриевна');
INSERT INTO `teachers` (`teacher_id`, `last_name`, `first_name`, `middle_name`) VALUES(5, 'Федоров', 'Михаил', 'Анатольевич');
INSERT INTO `teachers` (`teacher_id`, `last_name`, `first_name`, `middle_name`) VALUES(6, 'Иванов', 'Иван', 'Иванович');
INSERT INTO `teachers` (`teacher_id`, `last_name`, `first_name`, `middle_name`) VALUES(7, 'Петров', 'Петр', 'Петрович');
INSERT INTO `teachers` (`teacher_id`, `last_name`, `first_name`, `middle_name`) VALUES(8, 'Сидорова', 'Мария', 'Ивановна');

-- --------------------------------------------------------

--
-- Структура таблицы `users`
--

DROP TABLE IF EXISTS `users`;
CREATE TABLE `users` (
  `user_id` int(11) NOT NULL,
  `login` varchar(50) NOT NULL,
  `password` varchar(255) NOT NULL,
  `teacher_id` int(11) NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- ССЫЛКИ ТАБЛИЦЫ `users`:
--   `teacher_id`
--       `teachers` -> `teacher_id`
--

--
-- Дамп данных таблицы `users`
--

INSERT INTO `users` (`user_id`, `login`, `password`, `teacher_id`, `created_at`) VALUES(1, 'ivanov', '123', 1, '2025-11-27 23:55:11');
INSERT INTO `users` (`user_id`, `login`, `password`, `teacher_id`, `created_at`) VALUES(2, 'petrov', '456', 2, '2025-11-27 23:55:11');
INSERT INTO `users` (`user_id`, `login`, `password`, `teacher_id`, `created_at`) VALUES(3, 'sidorova', '789', 3, '2025-11-27 23:55:11');

--
-- Индексы сохранённых таблиц
--

--
-- Индексы таблицы `grades`
--
ALTER TABLE `grades`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `uk_grade_lesson` (`student_id`,`subject_id`,`grade_date`,`lesson_number`),
  ADD KEY `subject_id` (`subject_id`);

--
-- Индексы таблицы `specialties`
--
ALTER TABLE `specialties`
  ADD PRIMARY KEY (`specialty_id`),
  ADD UNIQUE KEY `group_name` (`group_name`);

--
-- Индексы таблицы `students`
--
ALTER TABLE `students`
  ADD PRIMARY KEY (`student_id`),
  ADD KEY `specialty_id` (`specialty_id`),
  ADD KEY `group_name` (`group_name`);

--
-- Индексы таблицы `subjects`
--
ALTER TABLE `subjects`
  ADD PRIMARY KEY (`subject_id`),
  ADD UNIQUE KEY `subject_name` (`subject_name`),
  ADD KEY `teacher_id` (`teacher_id`);

--
-- Индексы таблицы `teachers`
--
ALTER TABLE `teachers`
  ADD PRIMARY KEY (`teacher_id`);

--
-- Индексы таблицы `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`user_id`),
  ADD UNIQUE KEY `login` (`login`),
  ADD KEY `teacher_id` (`teacher_id`);

--
-- AUTO_INCREMENT для сохранённых таблиц
--

--
-- AUTO_INCREMENT для таблицы `grades`
--
ALTER TABLE `grades`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=110;

--
-- AUTO_INCREMENT для таблицы `specialties`
--
ALTER TABLE `specialties`
  MODIFY `specialty_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT для таблицы `students`
--
ALTER TABLE `students`
  MODIFY `student_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=58;

--
-- AUTO_INCREMENT для таблицы `subjects`
--
ALTER TABLE `subjects`
  MODIFY `subject_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- AUTO_INCREMENT для таблицы `teachers`
--
ALTER TABLE `teachers`
  MODIFY `teacher_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;

--
-- AUTO_INCREMENT для таблицы `users`
--
ALTER TABLE `users`
  MODIFY `user_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- Ограничения внешнего ключа сохраненных таблиц
--

--
-- Ограничения внешнего ключа таблицы `grades`
--
ALTER TABLE `grades`
  ADD CONSTRAINT `grades_ibfk_1` FOREIGN KEY (`student_id`) REFERENCES `students` (`student_id`),
  ADD CONSTRAINT `grades_ibfk_2` FOREIGN KEY (`subject_id`) REFERENCES `subjects` (`subject_id`);

--
-- Ограничения внешнего ключа таблицы `students`
--
ALTER TABLE `students`
  ADD CONSTRAINT `students_ibfk_1` FOREIGN KEY (`specialty_id`) REFERENCES `specialties` (`specialty_id`),
  ADD CONSTRAINT `students_ibfk_2` FOREIGN KEY (`group_name`) REFERENCES `specialties` (`group_name`);

--
-- Ограничения внешнего ключа таблицы `subjects`
--
ALTER TABLE `subjects`
  ADD CONSTRAINT `subjects_ibfk_1` FOREIGN KEY (`teacher_id`) REFERENCES `teachers` (`teacher_id`);

--
-- Ограничения внешнего ключа таблицы `users`
--
ALTER TABLE `users`
  ADD CONSTRAINT `users_ibfk_1` FOREIGN KEY (`teacher_id`) REFERENCES `teachers` (`teacher_id`) ON DELETE CASCADE;


--
-- Метаданные
--
USE `phpmyadmin`;

--
-- Метаданные для таблицы grades
--

--
-- Метаданные для таблицы specialties
--

--
-- Метаданные для таблицы students
--

--
-- Метаданные для таблицы subjects
--

--
-- Метаданные для таблицы teachers
--

--
-- Метаданные для таблицы users
--

--
-- Метаданные для базы данных university_journal
--
SET FOREIGN_KEY_CHECKS=1;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
